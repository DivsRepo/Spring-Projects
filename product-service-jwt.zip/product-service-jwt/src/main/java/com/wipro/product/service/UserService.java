package com.wipro.product.service;

import java.util.List;
import java.util.Map;

import com.wipro.product.dtoJWT.ApiResponse;

public interface UserService {

    List<Map<String, Object>> getAllUsers();

    Map<String, Object> getUserById(Long id);

    ApiResponse deleteUser(Long id);

    ApiResponse setEnabled(Long id, boolean enabled);
}
