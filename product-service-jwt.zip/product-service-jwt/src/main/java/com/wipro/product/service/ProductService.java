package com.wipro.product.service;



import java.util.List;

import com.wipro.product.dtoJWT.ProductRequest;
import com.wipro.product.dtoJWT.ProductResponse;

public interface ProductService {

    ProductResponse create(ProductRequest request, String createdBy);

    ProductResponse getById(Long id);

    List<ProductResponse> getAll();

    List<ProductResponse> search(String keyword);

    ProductResponse update(Long id, ProductRequest request);

    void delete(Long id);
}
