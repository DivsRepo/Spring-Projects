package com.wipro.product.exception;

public class ProductIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public ProductIdNotFoundException(int id) {
		super("Product not found with ID:" +id);
		
	}
}
