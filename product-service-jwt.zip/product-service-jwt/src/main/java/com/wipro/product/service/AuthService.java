package com.wipro.product.service;

import com.wipro.product.dtoJWT.JwtResponse;
import com.wipro.product.dtoJWT.LoginRequest;
import com.wipro.product.dtoJWT.RegisterRequest;

public interface AuthService {

    void register(RegisterRequest request);

    JwtResponse login(LoginRequest request);
}