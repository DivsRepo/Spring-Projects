package com.wipro.spring_security;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {
@GetMapping("/welcome")
public String WelcomeAuthentication() {
	return "Welcome to Spring Security";
}
@GetMapping("/user")
@PreAuthorize("hasRole('USER')")
public String userAccess() {
	return "Welcome USER";
}

@GetMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public String adminAccess() {
	return "Welcome ADMIN";
}
}