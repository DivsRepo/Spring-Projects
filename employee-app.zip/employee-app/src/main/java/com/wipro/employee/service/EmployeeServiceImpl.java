package com.wipro.employee.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exception.EmployeeIdNotFoundException;
import com.wipro.employee.repository.EmployeeRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;

@Service
//@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(@Autowired EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}
	
@Transactional
@Override
public Employee saveEmployee(Employee employee){
	return employeeRepository.save(employee);
}
@Override
public Employee findById(int id) {
	Optional<Employee> optionalContainer=employeeRepository.findById(id);
	if(optionalContainer.isPresent())
	return optionalContainer.get();
	else
		throw new EmployeeIdNotFoundException(id);
}

@Override
public List<Employee> findAll(){
	return employeeRepository.findAll();
}

@Override
public List<Employee> findByFirstName(String firstName) {
	return employeeRepository.findByFirstName(firstName);
}
@Override
public List<Employee> findByDepartment(String department) {
	return employeeRepository.findByDepartment(department);
}
}