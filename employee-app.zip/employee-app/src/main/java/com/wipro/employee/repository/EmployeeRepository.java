package com.wipro.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.employee.dto.request.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
	
	List<Employee> findByFirstName(String firstName);
	List<Employee> findByDepartment(String department);

}
