package com.wipro.employee.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.Mockito.verify;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.service.EmployeeService;

import tools.jackson.databind.ObjectMapper;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockitoBean
	private EmployeeService employeeService;
	
	@Autowired
	private ObjectMapper objectMapper;
	

	@Test
	void testSaveEmployee() throws Exception {
		//Arrange
		Employee actualEmployeeRequestBody = new Employee();
		actualEmployeeRequestBody.setFirstName("Arun");
		actualEmployeeRequestBody.setLastName("Kumar");
		actualEmployeeRequestBody.setDepartment("IT");
		actualEmployeeRequestBody.setSalary(45000);
		
				
		Employee savedEmployee = new Employee();
		savedEmployee.setId(1);;
		savedEmployee.setFirstName("Arun");
		savedEmployee.setLastName("Kumar");
		savedEmployee.setDepartment("IT");
		savedEmployee.setSalary(45000);
		
		//Mock Service Response
		when(employeeService.saveEmployee(any(Employee.class))).thenReturn(savedEmployee);
		
		// Act and Assert
		
		mockMvc.perform(post("/api/v1/employees")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(actualEmployeeRequestBody)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.firstName").value("Arun"))
				.andExpect(jsonPath("$.lastName").value("Kumar"))
				.andExpect(jsonPath("$.department").value("IT"));
	
		}
	@Test
	void testGetEmployeeById() throws Exception {
		//Arrange
		Employee employee = new Employee();
		employee.setId(1);
		employee.setFirstName("Arun");
		employee.setLastName("Kumar");
		employee.setDepartment("IT");
		employee.setSalary(45000);
		
		when(employeeService.findById(1)).thenReturn(employee);

		// Act and Assert
		
				mockMvc.perform(get("/api/v1/employees/1"))
						.andExpect(status().isOk())
						.andExpect(jsonPath("$.id").value(1))
						.andExpect(jsonPath("$.firstName").value("Arun"))
						.andExpect(jsonPath("$.lastName").value("Kumar"))
						.andExpect(jsonPath("$.department").value("IT"));
	verify(employeeService).findById(1);
	}
}
