package com.wipro.coupon.exception;

public class CouponIdNotFoundException extends RuntimeException{
	public CouponIdNotFoundException(int id) {
		super("Coupon not found with ID:" +id);
		
}
}
