package com.wipro.coupon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

import com.wipro.coupon.entity.Coupon;
import com.wipro.coupon.service.CouponService;


@RestController
@RequestMapping("api/v1/coupons")
public class CouponController {

	@Autowired
	private CouponService couponService;
	
	@PostMapping
	//@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon){
		return new ResponseEntity<>(
				couponService.saveCoupon(coupon), HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Coupon> findById(@PathVariable Integer id){
		return new ResponseEntity<>(couponService.findById(id),HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<Coupon>> findAll(){
		return new ResponseEntity<>(couponService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/code/{couponCode}")
	public ResponseEntity<List<Coupon>> findByCouponCode(@PathVariable String couponCode){
		return new ResponseEntity<>(couponService.findByCouponCode(couponCode),HttpStatus.OK);
	}
	
	
	@GetMapping("/instance")
	public String getInstance() {
		return "Coupon Service running on port:" + System.getProperty("server.port");
	}
	
	@Value("${app.message:Not Loaded}")
	private String configMessage;

	@GetMapping("/config-test")
	public String configTest() {
		return configMessage;
	}
	
}
