package com.wipro.coupon.service;


import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.coupon.entity.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.respository.CouponRepository;


import jakarta.transaction.Transactional;

@Service
public class CouponServiceImpl implements CouponService {

	@Autowired
	private com.wipro.coupon.respository.CouponRepository couponRepository;
	
	@Override
	public Coupon saveCoupon(Coupon coupon) {
		return couponRepository.save(coupon);
	}
	
	@Override
	public  Coupon findById(Integer id) {
		Optional<Coupon> optionalContainer= couponRepository.findById(id);
		if(optionalContainer.isPresent())
		return optionalContainer.get();
		else
			throw new CouponIdNotFoundException(id);
	}
	@Override
	public List<Coupon> findAll(){
		return  couponRepository.findAll();
	}
	@Override
	public List<Coupon> findByCouponCode(String couponCode) {
		return  couponRepository.findByCouponCode(couponCode);
	}
}
