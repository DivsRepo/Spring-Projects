package com.wipro.coupon.service;

import java.util.List;

import com.wipro.coupon.entity.Coupon;

public interface CouponService {

	Coupon saveCoupon(Coupon coupon);
	
	Coupon findById(Integer id);
	
	List<Coupon> findAll();
	List<Coupon> findByCouponCode(String couponCode);
	
}
