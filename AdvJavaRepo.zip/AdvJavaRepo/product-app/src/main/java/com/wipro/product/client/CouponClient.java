package com.wipro.product.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.wipro.product.dto.response.CouponResponse;

//@FeignClient(name="coupon-app", fallback=CouponClientFallback.class)
@FeignClient(name="coupon-app")
public interface CouponClient {
	
	@GetMapping("/api/v1/coupons/code/{couponCode}")
	List<CouponResponse> getCouponByCode(@PathVariable("couponCode") String couponCode);
}
