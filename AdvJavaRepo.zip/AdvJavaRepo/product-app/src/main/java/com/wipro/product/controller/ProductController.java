package com.wipro.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import com.wipro.product.dto.request.Product;
import com.wipro.product.dto.response.CouponResponse;
import com.wipro.product.service.ProductService;

import com.wipro.product.dto.response.ProductResponse;

import com.wipro.product.client.CouponClient;


@RestController
@RequestMapping("api/v1/products")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@Autowired
	private CouponClient couponClient;

@PostMapping(consumes="application/json",produces="application/json")
//@RequestMapping(method=RequestMethod.POST)
public ResponseEntity<Product> saveProduct(@RequestBody Product product){
	return new ResponseEntity<Product>(
			productService.saveProduct(product), HttpStatus.CREATED);
}

@GetMapping("/{id}")
public ResponseEntity<Product> Product(@PathVariable int id){
	return new ResponseEntity<Product>(productService.findById(id),HttpStatus.OK);
}

@GetMapping
public ResponseEntity<List<Product>> getAllProducts(){
	return new ResponseEntity<List<Product>>(productService.findAll(),HttpStatus.OK);
}

@GetMapping("/name/{productName}")
public ResponseEntity<List<Product>> getProductByName(@PathVariable String productName){
	return new ResponseEntity<List<Product>>(productService.findByProductName(productName),HttpStatus.OK);
}
@GetMapping("/category/{category}")
public ResponseEntity<List<Product>> Product(@PathVariable String category){
	return new ResponseEntity<List<Product>>(productService.findByCategory(category),HttpStatus.OK);
}
@GetMapping("/coupon/{couponCode}")
public ResponseEntity<List<CouponResponse>> getCouponDetails(@PathVariable("couponCode") String couponCode){
	return new ResponseEntity<>(productService.getCouponDetails(couponCode),HttpStatus.OK);
}

@CircuitBreaker(name="product-service", fallbackMethod="handleError")
@GetMapping("/discount/{productName}/{couponCode}")
public ResponseEntity<ProductResponse> getDiscountedProduct(@PathVariable String productName, @PathVariable String couponCode){
	List<Product> products=productService.findByProductName(productName);
	if(products.isEmpty()){
		return ResponseEntity.notFound().build();
	}
	List<CouponResponse> coupons = couponClient.getCouponByCode(couponCode);
	if(coupons.isEmpty()) {
		return ResponseEntity.notFound().build();
	}
	Product product=products.get(0);
	CouponResponse coupon = coupons.get(0);
	double discountPrice = product.getPrice()*coupon.getDiscountPercentage()/100;
	double finalPrice = product.getPrice() - discountPrice;
	ProductResponse response = new ProductResponse();
	response.setProductName(product.getProductName());
	response.setPrice(product.getPrice());
	response.setDiscountPrice(discountPrice);
	response.setFinalPrice(finalPrice);
	response.setStatus("Coupon Applied Successfully");
	return ResponseEntity.ok(response);
}
public ResponseEntity<ProductResponse> handleError(String productName, String couponCode, Throwable throwable){
	ProductResponse response= new ProductResponse();
			response.setProductName(productName);
			response.setStatus("Coupon Service is currently unavailable. Please try again later.");
			
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
	
}

@Value("${app.message:Not Loaded}")
private String configMessage;

@GetMapping("/config-test")
public String configTest() {
	return configMessage;
}


}


