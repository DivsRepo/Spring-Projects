package com.wipro.product.service;
import com.wipro.product.client.CouponClient;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.product.dto.request.Product;
import com.wipro.product.dto.response.CouponResponse;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.dto.request.Product;
import com.wipro.product.repository.ProductRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CouponClient couponClient;
	
	@Transactional
	@Override
	public Product saveProduct(Product product){
		return  productRepository.save( product);
	}
	@Override
	public  Product findById(int id) {
		Optional<Product> optionalContainer= productRepository.findById(id);
		if(optionalContainer.isPresent())
		return optionalContainer.get();
		else
			throw new ProductIdNotFoundException(id);
	}

	@Override
	public List<Product> findAll(){
		return  productRepository.findAll();
	}

	@Override
	public List<Product> findByProductName(String  productName) {
		return  productRepository.findByProductName(productName);
	}
	@Override
	public List<Product> findByCategory(String category) {
		return  productRepository.findByCategory(category);
	}
	@Override
	public List<CouponResponse> getCouponDetails(String couponCode){
		return couponClient.getCouponByCode(couponCode);
		
	}
	
}
