package com.wipro.product.client;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wipro.product.dto.response.CouponResponse;

@Component
public class CouponClientFallback implements CouponClient{

	@Override
	public List<CouponResponse>getCouponByCode(String couponCode){
		return Collections.emptyList();
		}
}
