package com.wipro.product.dto.response;

import java.time.LocalDate;

public class CouponResponse {
private Integer couponId;
private String couponCode;
private Double discountPercentage;
private LocalDate expiryDate;
public CouponResponse(Integer couponId, String couponCode, Double discountPercentage, LocalDate expiryDate) {
	super();
	this.couponId = couponId;
	this.couponCode = couponCode;
	this.discountPercentage = discountPercentage;
	this.expiryDate = expiryDate;
}
public Integer getCouponId() {
	return couponId;
}
public void setCouponId(Integer couponId) {
	this.couponId = couponId;
}
public String getCouponCode() {
	return couponCode;
}
public void setCouponCode(String couponCode) {
	this.couponCode = couponCode;
}
public Double getDiscountPercentage() {
	return discountPercentage;
}
public void setDiscountPercentage(Double discountPercentage) {
	this.discountPercentage = discountPercentage;
}
public LocalDate getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(LocalDate expiryDate) {
	this.expiryDate = expiryDate;
}



}
