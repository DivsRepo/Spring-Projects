package com.wipro.product.service;

import java.util.List;

import com.wipro.product.dto.request.Product;
import com.wipro.product.dto.response.CouponResponse;

public interface ProductService {
	Product saveProduct(Product product);
	Product findById(int id);
	List<Product> findAll();
	List<Product> findByProductName(String productName);
	List<Product> findByCategory(String category);
	List<CouponResponse> getCouponDetails(String couponCode);
}
